from setuptools import setup,find_packages

setup(
      name='yosstheboss',
      version='0.1',
      description='Clean and simple Instagram API for Python 3.x',
      packages=find_packages(),
      url='https://upload.pypi.org/legacy/',
      author='houhashv',
      author_email='yossihohashvili1@gmail.com'  
)