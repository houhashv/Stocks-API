from setuptools import setup

setup(
      name='yosstheboss',
      packages=['stocks'],
      version='0.1',
      description='Clean and simple Instagram API for Python 3.x'
)